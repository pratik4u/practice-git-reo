package com.cg.onlineplantnurseryapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlinePlantNurseryAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
