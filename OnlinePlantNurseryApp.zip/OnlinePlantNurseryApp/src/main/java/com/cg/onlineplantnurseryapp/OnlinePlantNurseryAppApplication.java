package com.cg.onlineplantnurseryapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlinePlantNurseryAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlinePlantNurseryAppApplication.class, args);
	}

}
